export type EDIField = {
  label: string;
  value: string | null;

  segment?: string;
  qualifier?: string;
  line?: number;
};

export type EDISection = {
  id: string;
  title: string;

  fields: EDIField[];
};

export type EDIAnalysis = {
  messageType: string;
  version: string | null;

  sections: EDISection[];

  segments: number;
  status: string;
};